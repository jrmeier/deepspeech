

#ffmpeg -i $MP3OUTPUT -acodec pcm_s16le -ac 1 -ar 16000 $WAVOUTPUT
